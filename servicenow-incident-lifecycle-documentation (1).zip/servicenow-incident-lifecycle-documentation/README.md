# Incident Lifecycle Automation in ServiceNow

## Project Overview

**Incident Lifecycle Automation in ServiceNow** is a practical ServiceNow workflow exercise that demonstrates how an IT support team can manage an incident from creation through classification, investigation, escalation, knowledge integration, child-incident creation, and resolution.

The documentation is based on the completed activities and screenshots captured during the SkillWallet ServiceNow practice project.

## Objectives

- Create and configure a business service named **Remote Access**.
- Create an incident related to a corporate VPN connectivity problem.
- Update and classify the incident with the required service-management details.
- Use **Agent Assist** to locate relevant knowledge articles.
- Reassign the incident to the appropriate support group.
- Track the incident through Level 2 investigation.
- Create and link a child incident.
- Record the probable cause of the issue.
- Create a knowledge article from the incident.
- Verify resolution, related records, change linkage, knowledge creation, and SLA tracking.

## Main Scenario

A user reported that they were unable to connect to the **Corporate VPN** from the home office.

The incident information used in the exercise included:

- **Short description:** Unable to connect to Corporate VPN from home office
- **Channel:** Phone
- **Category:** Network
- **Subcategory:** VPN
- **Urgency:** 2 – Medium
- **Service:** Remote Access
- **Service offering:** Corporate VPN
- **Configuration item:** ThinkStation S20
- **Work note:** Classified and assigned incident

The incident was later investigated by the Network team. The documented probable cause was:

> PowerEdge service was suspended and required restart.

## Workflow Demonstrated

```text
Create Service
      |
      v
Create Incident
      |
      v
Update and Classify Incident
      |
      v
Use Agent Assist and Knowledge Articles
      |
      v
Assign / Reassign to Support Group
      |
      v
Level 2 Investigation
      |
      v
Create Child Incident
      |
      v
Record Probable Cause
      |
      v
Create Knowledge Article
      |
      v
Resolve and Verify Related Records
```

## Implementation Steps

### 1. Create the Business Service

A new service was created from the ServiceNow service list.

Configuration used in the exercise:

- **Name:** Remote Access
- **Operational status:** Operational
- **Used for:** Production
- **Service classification:** Business Service

See: [`01_create_service.png`](screenshots/01_create_service.png)

### 2. Create the Incident

An incident was created from the Incidents module in Service Operations Workspace.

The incident represented a corporate VPN connectivity issue. The incident number was recorded for later tracking.

See: [`02_incident_list.png`](screenshots/02_incident_list.png)

### 3. Update and Classify the Incident

The incident was opened and updated from the **Details** tab.

The following values were entered or verified:

- Description of the authentication error
- Phone as the communication channel
- Network as the category
- VPN as the subcategory
- Medium urgency
- Remote Access as the service
- Corporate VPN as the service offering
- ThinkStation S20 as the configuration item

The incident was then assigned to the current user and saved.

See: [`03_update_incident_details.png`](screenshots/03_update_incident_details.png)

### 4. Verify Agent Assist

The **Agent Assist** panel was opened from the right side of the incident workspace.

Knowledge articles were selected so that the support agent could review possible solutions related to the VPN issue.

See: [`04_agent_assist_verification.png`](screenshots/04_agent_assist_verification.png)

### 5. Reassign the Incident

The assignment group was updated to **Network**.

The exercise also required checking whether the **Assigned to** field was cleared automatically when the assignment group changed.

See: [`05_reassignment.png`](screenshots/05_reassignment.png)

### 6. Track the Incident Through Level 2

The incident was opened from the Service Operations Workspace using the Open incidents list.

The workflow included checking:

- Incident description
- Knowledge articles
- SLA information in Task SLAs under Related Records

See: [`06_incident_tracking_level2.png`](screenshots/06_incident_tracking_level2.png)

### 7. Create a Child Incident

A child incident was created from the parent incident's **Related Records** tab.

Example child-incident details:

- **Short description:** Unable to connect to Corporate VPN
- **Caller:** Any valid user
- **Description:** User receiving VPN authentication failure error

After saving, the child incident was verified in the parent incident's related records.

See: [`07_create_child_incident.png`](screenshots/07_create_child_incident.png)

### 8. Record the Probable Cause

The incident's cause information was updated from the **Overview** tab.

The probable cause entered was:

> PowerEdge service was suspended and required restart.

See: [`08_add_cause.png`](screenshots/08_add_cause.png)

### 9. Create a Knowledge Article

A knowledge article was created from the incident workflow.

The documented process included:

1. Select **Create Knowledge**.
2. Choose **IT** as the Knowledge Base.
3. Select **Standard** as the article template.
4. Verify the article details.
5. Save the article.
6. Return to the parent incident.
7. Verify the created knowledge article under Related Records.

See: [`09_create_knowledge_article.png`](screenshots/09_create_knowledge_article.png)

### 10. Verify Resolution

The final verification included checking the following:

- Parent incident state is **Resolved**.
- Child incident state is **Resolved**.
- Activity stream shows that resolution was triggered by the parent.
- A change request is linked.
- A knowledge article has been created.
- SLA tracking is visible.

See: [`10_resolution_verification.png`](screenshots/10_resolution_verification.png)

## Outcome

This exercise demonstrates a structured incident-management lifecycle in ServiceNow. It connects incident handling with:

- Service configuration
- Incident classification
- Agent Assist and knowledge management
- Assignment and reassignment
- Level 2 investigation
- Child-incident management
- Cause documentation
- Knowledge creation
- Resolution verification
- SLA and related-record tracking

## Conclusion

The project shows how ServiceNow can support a consistent incident-management process. By using a common workflow, support teams can capture incident details, route issues to the correct team, reuse knowledge, track related records, and document the final resolution.

## Evidence

All screenshots used in this documentation are stored in the [`screenshots`](screenshots/) folder.

> **Note:** This repository documents the activities shown in the provided ServiceNow practice screenshots. It should be treated as a practical workflow record rather than a claim that every feature is custom-developed from scratch.
